
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('PRODUCTS MANAGEMENT')); ?></div>
                <div class="card-body">
                  <a class="btn btn-success" href="<?php echo e(url('add-new-product')); ?>">Add New Product</a>
                  <a class="btn btn-primary" href="<?php echo e(url('view-products')); ?>">View Products</a>
                
                </div>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\products-crud\resources\views/index.blade.php ENDPATH**/ ?>