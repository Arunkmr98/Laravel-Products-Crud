
<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row justify-content-center" style="margin-top:50px;">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><?php echo e(__('MANAGE PRODUCTS')); ?>

            <a href="<?php echo e(url('/')); ?>" class="btn btn-success" style="float:right">Back</a>
            </div>
            <div class="card-body">

              <table class="table table-stripped table-bordered">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Product Title</th>
            <th scope="col">Description</th>
            <th scope="col">Price</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if(!empty($products)): ?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($product->id); ?></td>
              <td><?php echo e($product->product_title); ?></td>
              <td><?php echo e($product->description); ?></td>
              <td><?php echo e($product->price); ?></td>
              <td>
                <a class="btn btn-primary" href="<?php echo e(url('product/edit/'.$product->id)); ?>">Edit</a>
                <a class="btn btn-danger" href="<?php echo e(url('product/delete/'.$product->id)); ?>">Delete</a>
              </td>

            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

        </tbody>
      </table>
        <a class="btn btn-info" href="<?php echo e(url('export-products')); ?>">Export Products</a>
          </div>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\products-crud\resources\views/product-list.blade.php ENDPATH**/ ?>