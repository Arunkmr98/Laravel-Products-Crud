
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('ADD PRODUCTS')); ?>

                  <a href="<?php echo e(url('/')); ?>" class="btn btn-success" style="float:right">Back</a>
                </div>
                <div class="card-body">
                  <form class="" action="<?php echo e(url('update-product')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="p_id" value="<?php echo e($productData->id); ?>" required readonly>

                    <div class="form-group">
                      <label for="title">Product Title</label>
                      <input class="form-control" type="text" name="product_title" value="<?php echo e($productData->product_title ?? ''); ?>" required placeholder="Product Title">
                    </div>

                    <div class="form-group">
                      <label for="Description">Product Description</label>
                      <textarea class="form-control" value="<?php echo e($productData->description ?? ''); ?>" name="detail" required><?php echo e($productData->description ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                      <label for="price">Product Price</label>
                      <input type="number" class="form-control" name="price" value="<?php echo e($productData->price ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                      <button class="btn btn-success" type="submit" name="button">Update Product</button>
                    </div>


                  </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\products-crud\resources\views/update-product.blade.php ENDPATH**/ ?>