<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('ADD PRODUCTS')); ?>

                  <a href="<?php echo e(url('/')); ?>" class="btn btn-success" style="float:right">Back</a>
                </div>
                <div class="card-body">
                  <form class="" action="<?php echo e(url('add-product')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <label for="title">Product Title</label>
                      <input class="form-control" type="text" name="product_title" value="" required placeholder="Product Title">
                    </div>

                    <div class="form-group">
                      <label for="Description">Product Description</label>
                      <textarea class="form-control" name="detail" required></textarea>
                    </div>

                    <div class="form-group">
                      <label for="price">Product Price</label>
                      <input type="number" class="form-control" name="price" value="" required>
                    </div>

                    <div class="form-group">
                      <button class="btn btn-success" type="submit" name="button">Add Product</button>
                    </div>


                  </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\products-crud\resources\views/home.blade.php ENDPATH**/ ?>